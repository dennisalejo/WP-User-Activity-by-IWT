<?php
/**
 * Plugin Name: WP User Activity by IWT
 * Description: This plugin logs user activities such as login, post/page edits, theme updates, and plugin updates including IP address, browser, date and time.
 * Version: 1.1
 * Author: Dennis Alejo
 * Author URI: https://dennis.tips
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WP_User_Activity_By_IWT {
    public function __construct() {
        add_action('wp_login', array($this, 'log_user_login'), 10, 2);
        add_action('save_post', array($this, 'log_post_edit'));
        add_action('activated_plugin', array($this, 'log_plugin_update'));
        add_action('switch_theme', array($this, 'log_theme_update'));
        add_action('admin_menu', array($this, 'register_activity_log_menu'));
        add_action('admin_init', array($this, 'settings_init'));
        add_action('init', array($this, 'create_log_table'));
    }

    public function create_log_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'activity_logs';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                username varchar(60) NOT NULL,
                user_ip varchar(100) NOT NULL,
                user_browser varchar(255) NOT NULL,
                activity_type varchar(100) NOT NULL,
                activity_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        } else {
            // Check if username column exists, if not add it
            $column = $wpdb->get_results("SHOW COLUMNS FROM $table_name LIKE 'username'");
            if (empty($column)) {
                $wpdb->query("ALTER TABLE $table_name ADD username varchar(60) NOT NULL");
            }
        }
    }

    public function log_user_login($user_login, $user) {
        $this->insert_log($user_login, 'user_login');
        $this->maybe_send_log_email();
    }

    public function log_post_edit($post_id) {
        $post = get_post($post_id);
        $user = get_user_by('ID', $post->post_author);
        $username = $user ? $user->user_login : 'unknown';
        $this->insert_log($username, 'post_edit');
    }

    public function log_plugin_update($plugin) {
        $user = wp_get_current_user();
        $username = $user ? $user->user_login : 'unknown';
        $this->insert_log($username, 'plugin_update');
    }

    public function log_theme_update($new_name) {
        $user = wp_get_current_user();
        $username = $user ? $user->user_login : 'unknown';
        $this->insert_log($username, 'theme_update');
    }

    private function insert_log($username, $activity_type) {
        if (!is_user_logged_in()) {
            error_log("User not logged in");
            return;
        }

        global $wpdb;
        
        // Confirm username is captured
        error_log("Logging activity: username=$username, activity_type=$activity_type");

        $user_ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
        $user_browser = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $current_time = current_time('mysql');
        
        $wpdb->insert(
            $wpdb->prefix . 'activity_logs',
            array(
                'username' => $username,
                'user_ip' => $user_ip,
                'user_browser' => $user_browser,
                'activity_type' => $activity_type,
                'activity_date' => $current_time,
            )
        );
    }

    public function register_activity_log_menu() {
        add_menu_page(
            'Activity Logs',
            'Activity Logs',
            'manage_options',
            'wp-activity-logger',
            array($this, 'display_activity_logs'),
            'dashicons-format-aside',
            6
        );
    }

    public function display_activity_logs() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'activity_logs';
        $logs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY activity_date DESC");

        echo '<div class="wrap">';
        echo '<h1>Activity Logs</h1>';
        echo '<table class="widefat fixed" cellspacing="0">';
        echo '<thead><tr><th>Username</th><th>IP Address</th><th>Browser</th><th>Activity Type</th><th>Date/Time</th></tr></thead>';
        echo '<tbody>';
        foreach ($logs as $log) {
            echo '<tr>';
            echo '<td>' . esc_html($log->username) . '</td>';
            echo '<td>' . esc_html($log->user_ip) . '</td>';
            echo '<td>' . esc_html($log->user_browser) . '</td>';
            echo '<td>' . esc_html($log->activity_type) . '</td>';
            echo '<td>' . esc_html($log->activity_date) . '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    }

    public function settings_init() {
        add_settings_section(
            'wp_activity_logger_section',
            'WP Activity Logger Settings',
            null,
            'general'
        );
        
        add_settings_field(
            'wp_activity_logger_email',
            'Log Email Address',
            array($this, 'log_email_field_callback'),
            'general',
            'wp_activity_logger_section'
        );

        register_setting('general', 'wp_activity_logger_email', 'sanitize_email');
    }

    public function log_email_field_callback() {
        printf(
            '<input type="email" id="wp_activity_logger_email" name="wp_activity_logger_email" value="%s" class="regular-text ltr" />',
            esc_attr(get_option('wp_activity_logger_email', ''))
        );
    }

    private function maybe_send_log_email() {
        $email = get_option('wp_activity_logger_email');

        if (!$email) {
            return;
        }

        global $wpdb;
        $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}activity_logs WHERE activity_date >= (NOW() - INTERVAL 1 DAY) ORDER BY activity_date DESC");
        
        if (empty($logs)) {
            return;
        }

        $subject = 'Daily Activity Logs';
        $message = '<h1>Daily Activity Logs</h1><table><thead><tr><th>Username</th><th>IP Address</th><th>Browser</th><th>Activity Type</th><th>Date/Time</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $message .= sprintf('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html($log->username), esc_html($log->user_ip), esc_html($log->user_browser), esc_html($log->activity_type), esc_html($log->activity_date));
        }
        $message .= '</tbody></table>';

        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail($email, $subject, $message, $headers);
    }
}

new WP_User_Activity_By_IWT();
?>